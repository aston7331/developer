let a = "programingspark";
let l = a.length;
let string = "";
var arr = [];

function arrayPush(element, arrayName){

        for(let j=0; j<arr; j++){
            if(element==arr[j]){
                string += arr[j];
            }else{
                arrayName.push[element];
            }
        }
    }


for (var i = 0; i < l; i++) {
    arrayPush(a[i], arr);
}

console.log(string);